import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {DatabaseSync} from 'node:sqlite';
import vm from 'node:vm';
import {PACKS,course,PHRASES,TEXT,TOTAL,LIMITS,CPU_DURATION,newPlayer,applyKey,advance,penalty,lapOf} from '../worker/game.js';
const server=(await import('../dist/server/index.js?test='+Date.now())).default;
assert(PHRASES[0].match(/^[a-z ]+$/));assert(/[A-Z]/.test(PHRASES[1]));assert(/[!:"?,.-]/.test(PHRASES[2]));
for(const [key,expected] of [['w',0],['a',0],['t',1],['g',1],['p',2],['l',2]])assert.equal(penalty('q',key),expected);
let p=newPlayer('p','t','Test','#45caff',0);p.correct=LIMITS[1];assert.equal(applyKey(p,'a',0),false);assert.equal(p.correct,LIMITS[1]);assert.equal(applyKey(p,'A',100),true);assert.equal(p.errors[0],1);
p=newPlayer('p','t','Test','#45caff',0);for(const key of TEXT)applyKey(p,key,0);assert.equal(p.correct,TOTAL);advance(p,100000,0);assert.equal(p.progress,TOTAL);assert(p.finishedAt<CPU_DURATION*1000);assert.equal(lapOf(LIMITS[2]),2);
p=newPlayer('p','t','Test','#45caff',0);applyKey(p,'p',0);const heavy=p.penaltyUntil;applyKey(p,'t',20);assert(p.penaltyUntil<heavy);assert.equal(p.correct,0);
const db=new DatabaseSync(':memory:');db.exec(readFileSync('drizzle/0000_rooms.sql','utf8'));
const env={DB:{prepare(sql){let args=[];return {bind(...a){args=a;return this},async first(){return db.prepare(sql).get(...args)},async run(){const r=db.prepare(sql).run(...args);return {meta:{changes:r.changes}}}}}}};
let now=1800000000000;const realNow=Date.now;Date.now=()=>now;
async function call(path,body){const r=await server.fetch(new Request('https://race.example'+path,{method:'POST',headers:{'Content-Type':'application/json','Origin':'https://race.example'},body:JSON.stringify(body)}),env);return {status:r.status,data:await r.json()}}
let r=await call('/api/rooms',{name:'Host <script>',color:'#45caff'});assert.equal(r.status,200);const host=r.data,code=host.room.code;assert(!host.room.players[0].token);assert.equal(host.room.players[0].name,'Host script');
const action=(a,b)=>call('/api/rooms/'+code+'/'+a,b);
assert.equal((await action('start',{token:host.token})).status,409);
const guest=(await action('join',{name:'Guest',color:'#ff59c7'})).data;
assert.equal((await action('start',{token:guest.token})).status,403);
for(let i=3;i<=12;i++){const joined=await action('join',{name:'Racer '+i});assert.equal(joined.status,200);assert.equal(joined.data.room.players.length,i)}
const full=await action('join',{name:'Racer 13'});assert.equal(full.status,409);assert.match(full.data.error,/12 racers/);
r=await action('start',{token:host.token});assert.equal(r.data.room.startAt,now+5000);
r=await action('sync',{token:host.token,keys:[{seq:1,key:TEXT[0]}]});assert.equal(r.data.room.players[0].correct,0);
assert.equal((await action('join',{name:'Late'})).status,409);
now+=5100;
r=await action('sync',{token:host.token,keys:[{seq:1,key:TEXT[0]}]});assert.equal(r.data.room.players[0].correct,1);
r=await action('sync',{token:host.token,keys:[{seq:1,key:TEXT[0]}]});assert.equal(r.data.room.players[0].correct,1);
assert.equal((await action('sync',{token:host.token,keys:[{seq:3,key:'x'}]})).status,409);
assert.equal((await action('sync',{token:'invalid'})).status,401);
let cursor=1;while(cursor<TOTAL){const chunk=[...TEXT].slice(cursor,cursor+100).map((key,i)=>({seq:cursor+i+1,key}));await action('sync',{token:host.token,keys:chunk});cursor+=chunk.length;}
now+=30000;r=await action('sync',{token:guest.token});assert.equal(r.data.room.status,'finished');assert.equal(r.data.room.winner,host.id);assert.equal(r.data.room.players[0].correct,TOTAL);
assert.equal((await action('rematch',{token:guest.token})).status,403);r=await action('rematch',{token:host.token});assert.equal(r.data.room.status,'lobby');assert.equal(r.data.room.players[0].correct,0);
// Another racer cannot overwrite a room because its version must still match.
const stored=db.prepare('SELECT version FROM rooms WHERE code=?').get(code);const stale=await env.DB.prepare('UPDATE rooms SET data=? WHERE code=? AND version=?').bind('{}',code,stored.version-1).run();assert.equal(stale.meta.changes,0);
// Execute the built browser script against a minimal DOM and test real key handling.
const html=await (await server.fetch(new Request('https://race.example/'),env)).text();const elements={},listeners={};
const el=id=>elements[id]??={id,style:{setProperty(){}},classList:{toggle(){}},setAttribute(){},addEventListener(){},insertAdjacentHTML(){},blur(){},focus(){},select(){},getContext(){return {}},hidden:false,value:'Racer',textContent:'',innerHTML:''};
const context={console,Date,Math,structuredClone,URLSearchParams,location:{search:'',protocol:'file:'},clearTimeout(){},setTimeout(){},requestAnimationFrame(){},document:{getElementById:el,documentElement:el('root'),querySelectorAll(){return []},addEventListener(){},activeElement:el('focus')},window:{addEventListener(k,v){listeners[k]=v}}};vm.createContext(context);vm.runInContext(html.match(/<script>([\s\S]*?)<\/script>/)[1],context);const run=s=>vm.runInContext(s,context);run('launch()');now+=3100;run('tick(.1)');for(const key of TEXT)listeners.keydown({key,preventDefault(){}});assert.equal(run('player.correct'),TOTAL);now+=30000;run('tick(.1)');assert.equal(run('state'),'finished');assert.equal(el('resultTitle').textContent,'YOU WIN.');
run('launch()');now+=3100;run('tick(.1);pause()');const before=run('elapsed');now+=10000;run('tick(.1)');assert.equal(run('elapsed'),before);run('pause()');now+=100;run('tick(.1)');assert(run('elapsed')<1);
assert.equal(Object.keys(PACKS).length,4);
assert.deepEqual(Object.values(PACKS).map(p=>p.name),['Original Neon Rush','Movies & TV','Recipes','Lyrics']);
assert.match(PACKS.tv.phrases[2],/May the Force/);assert.match(PACKS.music.phrases[2],/Hello from the other side/);
for(const id of ['tv','music']){assert(course(id).total>=300);assert(PACKS[id].phrases.every(p=>p.length>=90));}
for(const id of Object.keys(PACKS)){
 const pack=course(id);assert.equal(pack.phrases.length,3);if(id!=='tv')assert(/^[a-z ]+$/.test(pack.phrases[0]));assert(/[A-Z]/.test(pack.phrases[1]));assert(/[!:"?,.\/]/.test(pack.phrases[2]));assert(/^[\x20-\x7e]+$/.test(pack.text));
 let racer=newPlayer('theme','token','Theme Racer','#45caff',now,id);for(const key of pack.text)applyKey(racer,key,now);assert.equal(racer.correct,pack.total);advance(racer,now+40000,now);assert.equal(racer.progress,pack.total);assert.equal(lapOf(pack.limits[2],id),2);
 const themedHost=(await call('/api/rooms',{name:'Theme host',theme:id})).data;const root='/api/rooms/'+themedHost.room.code;assert.equal(themedHost.room.theme,id);assert.deepEqual(themedHost.room.phrases,pack.phrases);
 const themedGuest=(await call(root+'/join',{name:'Theme guest',theme:'not-the-host-pack'})).data;assert.equal(themedGuest.room.theme,id);assert(themedGuest.room.players.every(p=>p.theme===id));
 await call(root+'/start',{token:themedHost.token});now+=5100;
 for(let j=0;j<pack.total;j+=100)assert.equal((await call(root+'/sync',{token:themedHost.token,keys:[...pack.text].slice(j,j+100).map((key,k)=>({seq:j+k+1,key}))})).status,200);
 now+=40000;const outcome=(await call(root+'/sync',{token:themedGuest.token})).data;assert.equal(outcome.room.winner,themedHost.id);
 const again=(await call(root+'/rematch',{token:themedHost.token})).data;assert.equal(again.room.theme,id);assert(again.room.players.every(p=>p.theme===id&&p.correct===0));
 const nextTheme=id==='recipes'?'music':'recipes';
 assert.equal((await call(root+'/theme',{token:themedGuest.token,theme:nextTheme})).status,403);
 assert.equal((await call(root+'/theme',{token:themedHost.token,theme:'invalid'})).status,400);
 const changed=await call(root+'/theme',{token:themedHost.token,theme:nextTheme});assert.equal(changed.status,200);assert.equal(changed.data.room.code,themedHost.room.code);assert.equal(changed.data.room.players.length,2);assert.equal(changed.data.room.host,themedHost.id);assert(changed.data.room.players.every(p=>p.theme===nextTheme&&p.correct===0));assert.deepEqual(changed.data.room.phrases,course(nextTheme).phrases);
 const guestView=(await call(root+'/sync',{token:themedGuest.token})).data;assert.equal(guestView.room.theme,nextTheme);
 await call(root+'/start',{token:themedHost.token});assert.equal((await call(root+'/theme',{token:themedHost.token,theme:id})).status,409);
 now+=186000;await call(root+'/sync',{token:themedGuest.token});
 const selected=(await call(root+'/rematch',{token:themedHost.token,theme:id})).data;assert.equal(selected.room.code,themedHost.room.code);assert.equal(selected.room.theme,id);assert(selected.room.players.every(p=>p.theme===id));

 run(`setTheme('${id}');launch()`);now+=3100;run('tick(.1)');for(const key of pack.text)listeners.keydown({key,preventDefault(){}});assert.equal(run('player.correct'),pack.total);now+=40000;run('tick(.1)');assert.equal(run('state'),'finished');assert.equal(el('resultTitle').textContent,'YOU WIN.');assert(el('resultLetters').textContent.endsWith('/'+pack.total));
}
assert.equal(course('unknown').id,'neon');
run("home();openRoomSetup(true)");assert.equal(el('intro').hidden,true);assert.equal(el('roomSetup').hidden,false);assert.equal(el('roomSetupTitle').textContent,'Create Multiplayer Room');listeners.keydown({key:'Escape',preventDefault(){}});assert.equal(el('intro').hidden,false);assert.equal(el('roomSetup').hidden,true);
el('roomCode').value='ABC12345';run('openRoomSetup(false)');assert.equal(el('roomSetupTitle').textContent,'Join Multiplayer Room');assert.match(el('roomSetupDescription').textContent,/ABC12345/);run('closeRoomSetup()');
assert(!html.match(/<div id="intro"[\s\S]*?<div id="roomSetup"/)[0].includes('id="racerName"'));

run('home();launch()');now+=3100;run('tick(.1)');listeners.keydown({key:'Escape',preventDefault(){}});assert.equal(run('state'),'paused');assert.equal(el('paused').hidden,false);el('pauseHome').onclick();assert.equal(run('state'),'intro');assert.equal(el('intro').hidden,false);assert.equal(el('paused').hidden,true);assert.equal(run('player'),null);
run("mode='multi';state='racing';pause()");assert.equal(run('state'),'racing');assert.equal(run('raceMenuOpen'),true);assert.equal(el('paused').hidden,false);run('pause()');assert.equal(run('raceMenuOpen'),false);assert.equal(el('paused').hidden,true);


for(const phase of ['lobby','countdown','racing','finished']){
 const h=(await call('/api/rooms',{name:'Closing Host'})).data,root='/api/rooms/'+h.room.code,g=(await call(root+'/join',{name:'Closing Guest'})).data;
 if(phase!=='lobby')await call(root+'/start',{token:h.token});
 if(phase==='racing'){now+=5100;await call(root+'/sync',{token:h.token,keys:[{seq:1,key:TEXT[0]}]});}
 if(phase==='finished'){now+=186000;assert.equal((await call(root+'/sync',{token:g.token})).data.room.status,'finished');}
 const closed=await call(root+'/leave',{token:h.token});assert.equal(closed.data.room.status,'closed');assert.equal(closed.data.room.startAt,null);
 const next=await call(root+'/sync',{token:g.token,keys:[{seq:1,key:TEXT[0]}]});assert.equal(next.data.room.status,'closed');assert.equal(next.data.room.players.find(p=>p.id===g.id).correct,0);
 now+=190000;assert.equal((await call(root+'/sync',{token:g.token})).data.room.status,'closed');assert.equal((await call(root+'/join',{name:'Too Late'})).status,410);
}
const stayHost=(await call('/api/rooms',{name:'Staying Host'})).data,stayRoot='/api/rooms/'+stayHost.room.code,leaveGuest=(await call(stayRoot+'/join',{name:'Leaving Guest'})).data;
await call(stayRoot+'/start',{token:stayHost.token});assert.equal((await call(stayRoot+'/leave',{token:leaveGuest.token})).data.room.status,'racing');assert.equal((await call(stayRoot+'/sync',{token:stayHost.token})).data.room.status,'racing');
context.fetch=async()=>Response.json({room:{status:'closed'}});context.AbortSignal=AbortSignal;
run("mode='multi';state='racing';room={code:'ABC12345'};token='guest-token';pending=[{seq:1,key:'r'}]");await run('sync()');assert.equal(run('state'),'intro');assert.equal(run('mode'),'solo');assert.equal(run('room'),null);assert.equal(run('pending.length'),0);assert.equal(el('intro').hidden,false);assert.match(el('notice').textContent,/host returned to the main menu/);
Date.now=realNow;console.log('PASS: all four packs, three-lap progression, exact themed typing, solo wins, host/guest pack consistency, server winners, theme-preserving rematches, in-room theme changes, host authorization, mid-race lock, legacy fallback, 12-player capacity, penalties, pause, host shutdown across race phases, guest return-to-menu and non-host departure.');
