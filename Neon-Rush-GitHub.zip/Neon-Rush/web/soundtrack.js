// Original procedural synthwave score: 124 BPM, eight bars, A minor / F / C / G.
// Audio is generated locally; there are no external tracks or downloads.
const soundtrack=(()=>{
 const BPM=124,STEP=60/BPM/4,roots=[33,29,36,31];
 let enabled=true,volume=.35,desired=false,ctx=null,master=null,pads=null,delaySend=null,reverbSend=null,noise=null;
 let timer=null,suspendTimer=null,step=0,nextTime=0,unavailable=false;
 const voices=new Set();
 try{const saved=JSON.parse(localStorage.getItem('neon-rush-audio')||'null');if(saved){enabled=saved.enabled!==false;const value=Number(saved.volume);if(Number.isFinite(value))volume=Math.max(0,Math.min(1,value))}}catch{}
 const hz=midi=>440*2**((midi-69)/12);
 function prefs(){try{localStorage.setItem('neon-rush-audio',JSON.stringify({enabled,volume}))}catch{}}
 function ui(){const b=document.getElementById('musicToggle'),s=document.getElementById('musicVolume');if(!b||!s)return;b.textContent=unavailable?'MUSIC UNAVAILABLE':enabled?'♫ MUSIC ON':'♫ MUSIC OFF';b.setAttribute('aria-pressed',String(enabled&&!unavailable));b.title=unavailable?'Audio is unavailable in this browser':'Original synthwave soundtrack · starts with the race';s.value=String(Math.round(volume*100));s.setAttribute('aria-valuetext',Math.round(volume*100)+' percent');}
 function track(node){voices.add(node);node.onended=()=>{voices.delete(node);node.disconnect()};return node}
 function gain(value){const g=ctx.createGain();g.gain.value=value;return g}
 function init(){if(ctx||unavailable)return;const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio){unavailable=true;ui();return}try{
  ctx=new Audio();master=gain(0);const compressor=ctx.createDynamicsCompressor();compressor.threshold.value=-14;compressor.knee.value=18;compressor.ratio.value=5;compressor.attack.value=.008;compressor.release.value=.2;const low=ctx.createBiquadFilter();low.type='highpass';low.frequency.value=27;master.connect(low);low.connect(compressor);compressor.connect(ctx.destination);
  pads=gain(.36);pads.connect(master);
  const echo=ctx.createDelay(1),feedback=gain(.32),wet=gain(.22),echoFilter=ctx.createBiquadFilter();echo.delayTime.value=60/BPM*.75;echoFilter.type='lowpass';echoFilter.frequency.value=2700;delaySend=gain(1);delaySend.connect(echo);echo.connect(echoFilter);echoFilter.connect(feedback);feedback.connect(echo);echoFilter.connect(wet);wet.connect(master);
  const convolver=ctx.createConvolver(),impulse=ctx.createBuffer(2,Math.floor(ctx.sampleRate*2.4),ctx.sampleRate);let seed=19;for(let c=0;c<2;c++){const data=impulse.getChannelData(c);for(let i=0;i<data.length;i++){seed=(seed*16807)%2147483647;data[i]=(seed/1073741824-1)*(1-i/data.length)**3*.3}}convolver.buffer=impulse;reverbSend=gain(.22);reverbSend.connect(convolver);convolver.connect(master);
  noise=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);const data=noise.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=Math.random()*2-1;
 }catch{unavailable=true;ui();}}
 function tone(midi,type,time,duration,level,filterFreq,bus=master,detune=0){const o=track(ctx.createOscillator()),a=gain(0),f=ctx.createBiquadFilter();o.type=type;o.frequency.value=hz(midi);o.detune.value=detune;f.type='lowpass';f.frequency.setValueAtTime(filterFreq,time);f.frequency.exponentialRampToValueAtTime(Math.max(100,filterFreq*.45),time+duration);a.gain.setValueAtTime(.0001,time);a.gain.exponentialRampToValueAtTime(level,time+.015);a.gain.exponentialRampToValueAtTime(.0001,time+duration);o.connect(f);f.connect(a);a.connect(bus);o.start(time);o.stop(time+duration+.03);o.onended=()=>{voices.delete(o);o.disconnect();f.disconnect();a.disconnect()};return a;}
 function kick(time){const o=track(ctx.createOscillator()),a=gain(0);o.frequency.setValueAtTime(145,time);o.frequency.exponentialRampToValueAtTime(43,time+.12);a.gain.setValueAtTime(.65,time);a.gain.exponentialRampToValueAtTime(.0001,time+.34);o.connect(a);a.connect(master);o.start(time);o.stop(time+.36);o.onended=()=>{voices.delete(o);o.disconnect();a.disconnect()};pads.gain.setValueAtTime(.15,time);pads.gain.linearRampToValueAtTime(.36,time+.19);}
 function percussion(time,snare=false,open=false){const src=track(ctx.createBufferSource()),f=ctx.createBiquadFilter(),a=gain(0),dur=snare?.17:open?.13:.045;src.buffer=noise;f.type='highpass';f.frequency.value=snare?1600:8000;a.gain.setValueAtTime(snare?.19:open?.075:.05,time);a.gain.exponentialRampToValueAtTime(.0001,time+dur);src.connect(f);f.connect(a);a.connect(master);src.start(time);src.stop(time+dur+.02);src.onended=()=>{voices.delete(src);src.disconnect();f.disconnect();a.disconnect()};if(snare)tone(50,'triangle',time,.12,.10,1800);}
 function schedule(index,time){const n=index%16,bar=Math.floor(index/16)%8,chord=Math.floor(bar/2),root=roots[chord];
  if(n%4===0)kick(time);if(n===4||n===12)percussion(time,true);if(n%2===0)percussion(time,false,n===14);
  if([0,3,6,8,10,14].includes(n)){tone(root+(n===14?12:0),'sawtooth',time,.19,.11,650);tone(root,'sine',time,.25,.15,200);}
  if(n===0&&bar%2===0){const thirds=chord===0?3:4;for(const note of [root+24,root+24+thirds,root+31]){const voice=tone(note,'sawtooth',time,STEP*31,.045,900,pads,-6);voice.connect(reverbSend);tone(note,'sawtooth',time+.025,STEP*30,.035,1300,pads,6)}}
  if([2,5,7,10,13,15].includes(n)){const pattern=[0,7,12,15,12,7],interval=pattern[[2,5,7,10,13,15].indexOf(n)];const note=root+36+interval-(chord!==0&&interval===15? -1:0),voice=tone(note,'triangle',time,.35,.07,4200);voice.connect(delaySend);voice.connect(reverbSend);}
 }
 function pump(){if(!ctx||!desired||!enabled||ctx.state!=='running')return;const now=ctx.currentTime;if(nextTime<now-.2)nextTime=now+.03;while(nextTime<now+.14){schedule(step++,nextTime);nextTime+=STEP}}
 function play(){if(!ctx||ctx.state!=='running'||!desired||!enabled||timer!==null)return;if(suspendTimer!==null){clearTimeout(suspendTimer);suspendTimer=null}master.gain.cancelScheduledValues(ctx.currentTime);master.gain.setTargetAtTime(volume*.65,ctx.currentTime,.055);nextTime=ctx.currentTime+.04;step=0;pump();timer=setInterval(pump,35);}
 function stop(){if(timer!==null){clearInterval(timer);timer=null}if(!ctx)return;master.gain.cancelScheduledValues(ctx.currentTime);master.gain.setTargetAtTime(0,ctx.currentTime,.025);for(const node of voices){try{node.stop(ctx.currentTime+.08)}catch{}}if(suspendTimer!==null)clearTimeout(suspendTimer);suspendTimer=setTimeout(()=>{suspendTimer=null;if(ctx&&(!desired||!enabled))ctx.suspend().catch(()=>{})},400);}
 function unlock(){if(!enabled)return;init();if(!ctx)return;if(suspendTimer!==null){clearTimeout(suspendTimer);suspendTimer=null}ctx.resume().then(play).catch(()=>{document.getElementById('musicToggle').textContent='♫ TAP FOR MUSIC'});}
 function setActive(active){if(desired===active)return;desired=active;if(active){if(ctx)unlock()}else stop()}
 function bind(){ui();const toggle=document.getElementById('musicToggle'),slider=document.getElementById('musicVolume');toggle.onclick=()=>{enabled=!enabled;prefs();ui();if(enabled)unlock();else stop()};slider.oninput=()=>{volume=Math.max(0,Math.min(1,Number(slider.value)/100));prefs();if(ctx&&master&&enabled&&desired)master.gain.setTargetAtTime(volume*.65,ctx.currentTime,.04);ui()};
  // Room guests unlock audio with their join gesture before the shared countdown.
  for(const id of ['start','restart','resume','createRoom','joinRoom','roomSetupSubmit','hostStart'])document.getElementById(id).addEventListener('click',unlock);
  document.addEventListener('visibilitychange',()=>{if(document.hidden)setActive(false)});
 }
 return {bind,setActive,unlock};
})();
soundtrack.bind();
