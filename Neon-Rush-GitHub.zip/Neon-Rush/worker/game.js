export const MAX_PLAYERS=12;
// Four packs; quoted passages use short, attributed excerpts. Case and punctuation are formatted for typing.
export const PACKS = {
  "neon": {
    "id": "neon",
    "name": "Original Neon Rush",
    "description": "The original neon circuit. Racing words, glowing tracks, and precision.",
    "sky": "#060916",
    "horizon": "#10152f",
    "accent": "#45caff",
    "phrases": [
      "race into the neon night and keep your eyes on the road as the bright blue lights guide you home",
      "Accelerate through the illuminated arena while maintaining rhythm and overtaking determined competitors",
      "Precision matters: \"Stay focused!\" Navigate razor-sharp corners, avoid distractions, and claim victory!"
    ],
    "credits": []
  },
  "tv": {
    "id": "tv",
    "name": "Movies & TV",
    "description": "Star Wars and Stranger Things: cinematic adventures, familiar worlds, and memorable short quotes.",
    "sky": "#100819",
    "horizon": "#2b163a",
    "accent": "#cc9bff",
    "phrases": [
      "heroes race across a galaxy far away while a group of friends in hawkins sets out to solve a mystery",
      "Star Wars explores extraordinary galaxies while Stranger Things follows courageous friendships and mysterious adventures",
      "Star Wars: \"May the Force be with you.\" Stranger Things: \"Friends don't lie.\" Race on; the final scene is yours!"
    ],
    "credits": [
      [
        "Star Wars quote",
        "https://www.starwars.com/news/the-history-of-may-the-4th"
      ],
      [
        "Stranger Things quote",
        "https://www.netflix.com/tudum/articles/vecna-actor-stranger-things-interview-jamie-campbell-bower"
      ]
    ]
  },
  "recipes": {
    "id": "recipes",
    "name": "Recipes",
    "description": "From simple kitchen words to ingredients, measurements, and recipe instructions.",
    "sky": "#11100a",
    "horizon": "#2d2219",
    "accent": "#ffbd72",
    "phrases": [
      "mix flour and milk in a bowl then stir the batter until smooth and add a little oil to the warm pan",
      "Prepare a comforting vegetable pasta by combining tomatoes garlic and basil then gently sprinkle parmesan over each serving",
      "Pancakes: whisk 1 cup flour, 2 eggs, and 3/4 cup milk. Stir gently; cook until golden, then serve!"
    ],
    "credits": []
  },
  "music": {
    "id": "music",
    "name": "Lyrics",
    "description": "Artist names, concert vocabulary, and tiny lyric fragments from familiar songs.",
    "sky": "#100719",
    "horizon": "#32152c",
    "accent": "#ff86ce",
    "phrases": [
      "adele and taylor swift fill the stage with music as the beatles bring a bright melody to the crowd",
      "Adele delivers powerful performances while Taylor Swift celebrates storytelling and The Beatles inspire unforgettable harmonies",
      "The Beatles: \"Here comes the sun.\" Adele: \"Hello from the other side.\" Taylor Swift: \"Shake it off!\""
    ],
    "credits": [
      [
        "The Beatles - Here Comes the Sun",
        "https://www.thebeatles.com/here-comes-sun"
      ],
      [
        "Adele - Hello",
        "https://www.adele.com/clips/"
      ],
      [
        "Taylor Swift - Shake It Off",
        "https://www.youtube.com/watch?v=nfWlot6h_JM"
      ]
    ]
  }
};
const COURSES=Object.fromEntries(Object.values(PACKS).map(pack=>{const text=pack.phrases.join(''),total=text.length;return [pack.id,{...pack,text,total,cpuDuration:total/(40*5/60),limits:[0,pack.phrases[0].length,pack.phrases[0].length+pack.phrases[1].length,total]}]}));
export function course(id='neon'){return Object.hasOwn(COURSES,id)?COURSES[id]:COURSES.neon}
// Default exports also keep old rooms and saved single-player games compatible.
export const {phrases:PHRASES,text:TEXT,total:TOTAL,cpuDuration:CPU_DURATION,limits:LIMITS}=course('neon');
const positions={};['qwertyuiop[]','asdfghjkl;\'','zxcvbnm,./'].forEach((row,r)=>[...row].forEach((k,c)=>positions[k]=[c+[0,.25,.75][r],r]));
Object.assign(positions,{'1':[0,-1],'2':[1,-1],'3':[2,-1],'4':[3,-1],'5':[4,-1],'6':[5,-1],'7':[6,-1],'8':[7,-1],'9':[8,-1],'0':[9,-1],'-':[10,-1],'=':[11,-1]});
function base(k){return ({'!':'1','?':'/','"':"'",':':';','<':',','>':'.','_':'-','+':'=','(':'9',')':'0'})[k]||k.toLowerCase()}
export function penalty(expected,pressed){if(expected===' '||pressed===' ')return 0;if(base(expected)===base(pressed))return 0;const a=positions[base(expected)],b=positions[base(pressed)];if(!a||!b)return 0;const d=Math.hypot(a[0]-b[0],a[1]-b[1]);return d<=1.8?0:d<=4.5?1:2}
export function newPlayer(id,token,name,color,now,theme='neon'){return {id,token,name,color,theme:course(theme).id,correct:0,progress:0,errors:[0,0,0],penaltyUntil:0,severity:0,lastSeq:0,lastAt:now,seen:now,finishedAt:null}}
export function applyKey(p,key,now){const {text:TEXT,total:TOTAL}=course(p.theme);if(p.correct>=TOTAL)return;if(key===TEXT[p.correct]){p.correct++;return true}p.severity=penalty(TEXT[p.correct],key);p.errors[p.severity]++;p.penaltyUntil=now+[500,1000,1500][p.severity];return false}
export function advance(p,now,startAt){const {total:TOTAL}=course(p.theme);let from=Math.max(p.lastAt,startAt);if(now<=from||p.finishedAt){p.lastAt=Math.max(p.lastAt,now);return} // Integrate both sides of a penalty expiry exactly.
 const cuts=p.penaltyUntil>from&&p.penaltyUntil<now?[p.penaltyUntil,now]:[now];
 for(const to of cuts){const gap=p.correct-p.progress;if(gap>0){const slow=from<p.penaltyUntil?[.8,.5,.28][p.severity]:1;const rate=12*slow;const move=Math.min(gap,rate*(to-from)/1000);p.progress+=move;if(p.correct===TOTAL&&p.progress>=TOTAL-1e-8){p.progress=TOTAL;p.finishedAt=from+(gap/rate)*1000;break}}from=to}p.lastAt=now;
}
export function lapOf(correct,theme='neon'){const {limits:LIMITS}=course(theme);return correct<LIMITS[1]?0:correct<LIMITS[2]?1:2}
